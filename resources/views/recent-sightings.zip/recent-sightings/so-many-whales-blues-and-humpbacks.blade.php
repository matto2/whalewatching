@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Whale Watching in Monterey Bay') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')
					@include('includes.2016.so-many-whales-blues-and-humpbacks')
@stop

@section('scripts')
@append
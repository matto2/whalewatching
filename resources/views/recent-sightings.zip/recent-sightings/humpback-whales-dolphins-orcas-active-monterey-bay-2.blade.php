@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Whale Watching in Monterey Bay') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')
					@include('includes.2014.humpback-whales-dolphins-orcas-active-monterey-bay-2')
@stop

@section('scripts')
@append
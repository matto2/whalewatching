@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Monterey Bay whales breaching, tail slapping and feeding on anchovies') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')

					@include('includes.monterey-bay-whales-breaching-tail-slapping-feeding-anchovies')
@stop

@section('scripts')
@append
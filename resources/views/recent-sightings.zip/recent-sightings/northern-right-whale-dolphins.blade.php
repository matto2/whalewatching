@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Recent Sightings While Whale Watching in Monterey Bay') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')

					@include('includes.northern-right-whale-dolphins')
@stop

@section('scripts')
@append
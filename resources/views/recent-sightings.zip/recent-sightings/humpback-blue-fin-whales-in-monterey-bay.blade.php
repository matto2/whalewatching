@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Whale Watching in Monterey Bay') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')
					@include('includes.2016.humpback-blue-fin-whales-in-monterey-bay')
@stop

@section('scripts')
@append
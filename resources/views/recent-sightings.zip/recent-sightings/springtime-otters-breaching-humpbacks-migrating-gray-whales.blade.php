@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Springtime otters, breaching humpbacks, migrating gray whales') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')

					@include('includes.springtime-otters-breaching-humpbacks-migrating-gray-whales')
@stop

@section('scripts')
@append
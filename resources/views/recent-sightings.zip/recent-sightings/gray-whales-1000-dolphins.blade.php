@extends('layouts.frontend')

@section('head')
<title>{{ pageTitle('Whale Watching in Monterey Bay') }}</title>
@stop

@section('stylesheets')
@stop

@section('title')
@stop

@section('content')
					@include('includes.2016.gray-whales-1000-dolphins')
@stop

@section('scripts')
@append